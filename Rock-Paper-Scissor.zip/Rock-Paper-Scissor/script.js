let userScore = 0;
let compScore = 0;


const userScorepara = document.querySelector("#user-score");
const compScorepara = document.querySelector("#comp-score");

const message = document.querySelector(".msg");

const choices = document.querySelectorAll(".choice");


const gencompchoose = () => {
    const options = ["rock" , "paper" , "scissor"];
    const rdmidx = Math.floor(Math.random()*3);
    return options[rdmidx];
};


const drawGame = () => {
    console.log("Game was Draw ");
    message.innerText = "Game was draw";
    message.style.backgroundColor = "#081b31";

};

const showWinner = (userwin , userChoice , compChoice) => {
    if(userwin){
        console.log("you win");
        message.innerText = `you win! your ${userChoice} beats ${compChoice}`;
        message.style.backgroundColor = "green";
        userScore++;
        userScorepara.innerText = userScore;
        
    
    }
    else{
        console.log("you lose");
        message.innerText = `you lose. ${compChoice} beats your ${userChoice}`;
        message.style.backgroundColor = "red";
        compScore++;
        compScorepara.innerText = compScore;

    
    }
}

const playGame = (userChoice) => {
    console.log("user choice = " , userChoice)
// generate computer choice 
const compChoice = gencompchoose();
   console.log("comp choisee = " , compChoice);


   if(userChoice === compChoice){
     drawGame();
   }
   else{
     let userwin = true;
   if(userChoice === "rock"){
     userwin = compChoice === "paper" ? false : true;
    }
   else if(userChoice === "paper"){
    userwin = compChoice === "scissor" ? false : true;
   }
   else{
    userwin = compChoice === "rock" ? false : true;
   }
   showWinner(userwin , userChoice , compChoice);
  }
}



choices.forEach((choice) => {
    choice.addEventListener("click" , () => {
        const userChoice = choice.getAttribute("id");
        playGame(userChoice);
    });
}); 




